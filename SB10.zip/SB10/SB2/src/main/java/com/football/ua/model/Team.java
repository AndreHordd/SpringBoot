package com.football.ua.model;

public class Team {
    public Long id;
    public String name;
    public String league;
    public String city;
    public String colors;
    public String emblemUrl;
}

