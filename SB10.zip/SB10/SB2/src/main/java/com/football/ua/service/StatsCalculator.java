package com.football.ua.service;

public interface StatsCalculator {
    double homeWinProbability(String homeTeam, String awayTeam);
}