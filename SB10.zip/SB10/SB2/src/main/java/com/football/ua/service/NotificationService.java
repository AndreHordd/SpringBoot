package com.football.ua.service;

public interface NotificationService {
    void notifyAll(String channel, String message);
}