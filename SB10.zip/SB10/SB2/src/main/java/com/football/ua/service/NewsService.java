package com.football.ua.service;

public interface NewsService {
    String publish(String title, String body);
}