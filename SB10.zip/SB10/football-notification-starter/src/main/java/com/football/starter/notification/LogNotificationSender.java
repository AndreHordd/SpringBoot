package com.football.starter.notification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class LogNotificationSender implements NotificationSender {

    private static final Logger logger = LoggerFactory.getLogger(LogNotificationSender.class);
    
    @Override
    public void send(String message) {
        logger.info("Notification: {}", message);
    }
    
    @Override
    public void send(String subject, String message) {
        logger.info("Notification [{}]: {}", subject, message);
    }
}


