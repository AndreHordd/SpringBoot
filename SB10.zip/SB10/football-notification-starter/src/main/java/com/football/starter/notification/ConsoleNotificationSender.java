package com.football.starter.notification;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class ConsoleNotificationSender implements NotificationSender {
    
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final String prefix;
    
    public ConsoleNotificationSender(String prefix) {
        this.prefix = prefix != null ? prefix : "NOTIFICATION";
    }
    
    @Override
    public void send(String message) {
        String timestamp = LocalDateTime.now().format(FORMATTER);
        System.out.println(String.format("[%s] [%s] %s", timestamp, prefix, message));
    }
    
    @Override
    public void send(String subject, String message) {
        String timestamp = LocalDateTime.now().format(FORMATTER);
        System.out.println(String.format("[%s] [%s] %s: %s", timestamp, prefix, subject, message));
    }
}


