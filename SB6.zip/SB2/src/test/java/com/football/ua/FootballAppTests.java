package com.football.ua;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballAppTests {

	@Test
	void contextLoads() {
	}

}
