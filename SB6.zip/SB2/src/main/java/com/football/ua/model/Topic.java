package com.football.ua.model;

public class Topic {
    public Long id;
    public String title;
    public String author;

}