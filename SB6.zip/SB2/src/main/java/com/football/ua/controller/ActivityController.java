package com.football.ua.controller;

import com.football.ua.model.ActivityLog;
import com.football.ua.service.ActivityLogService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/activity")
public class ActivityController {
    
    private final ActivityLogService activityLogService;
    
    public ActivityController(ActivityLogService activityLogService) {
        this.activityLogService = activityLogService;
    }
    
    @GetMapping
    public String activityPage() {
        return "activity";
    }
    
    @GetMapping("/api/recent")
    @ResponseBody
    public List<ActivityLog> getRecent(@RequestParam(defaultValue = "50") int limit) {
        return activityLogService.getRecentActivities(limit);
    }
    
    @GetMapping("/api/category/{category}")
    @ResponseBody
    public List<ActivityLog> getByCategory(
            @PathVariable String category, 
            @RequestParam(defaultValue = "50") int limit) {
        return activityLogService.getActivitiesByCategory(category, limit);
    }
}

