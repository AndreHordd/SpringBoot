package com.football.ua.model;

public class Post {
    public Long id;
    public Long topicId;
    public String author;
    public String text;
}