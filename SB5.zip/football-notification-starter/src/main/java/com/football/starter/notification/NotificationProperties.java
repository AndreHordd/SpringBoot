package com.football.starter.notification;

import org.springframework.boot.context.properties.ConfigurationProperties;


@ConfigurationProperties(prefix = "football.notification")
public class NotificationProperties {

    private boolean enabled = true;

    private String type = "console";

    private String prefix = "⚽ FOOTBALL";
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getPrefix() {
        return prefix;
    }
    
    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }
}


