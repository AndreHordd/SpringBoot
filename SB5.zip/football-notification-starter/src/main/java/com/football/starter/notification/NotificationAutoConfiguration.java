package com.football.starter.notification;

import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnClass(NotificationSender.class)
@ConditionalOnProperty(prefix = "football.notification", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(NotificationProperties.class)
public class NotificationAutoConfiguration {
    
    private final NotificationProperties properties;
    
    public NotificationAutoConfiguration(NotificationProperties properties) {
        this.properties = properties;
        System.out.println("Football Notification Starter активовано!");
        System.out.println("Тип: " + properties.getType());
        System.out.println("Префікс: " + properties.getPrefix());
    }
    
    @Bean
    @ConditionalOnProperty(prefix = "football.notification", name = "type", havingValue = "console", matchIfMissing = true)
    @ConditionalOnMissingBean
    public NotificationSender consoleNotificationSender() {
        System.out.println("Створено ConsoleNotificationSender");
        return new ConsoleNotificationSender(properties.getPrefix());
    }
    
    @Bean
    @ConditionalOnProperty(prefix = "football.notification", name = "type", havingValue = "log")
    @ConditionalOnMissingBean
    public NotificationSender logNotificationSender() {
        System.out.println("Створено LogNotificationSender");
        return new LogNotificationSender();
    }
}


