package com.football.starter.notification;

public interface NotificationSender {

    void send(String message);

    void send(String subject, String message);
}


