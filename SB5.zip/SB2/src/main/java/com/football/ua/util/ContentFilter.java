package com.football.ua.util;

public interface ContentFilter {
    String filter(String input);
}
